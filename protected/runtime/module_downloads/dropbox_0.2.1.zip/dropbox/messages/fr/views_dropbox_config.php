<?php
return array (
  '<strong>Dropbox</strong> settings' => '<strong>Paramètres</strong> dropbox',
  'Submit' => 'Envoyer',
);
