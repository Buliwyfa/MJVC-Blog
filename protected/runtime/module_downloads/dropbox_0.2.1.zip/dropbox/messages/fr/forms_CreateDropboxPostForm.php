<?php
return array (
  'Invalid file' => 'Fichier invalide',
  'Message' => 'Message',
);
