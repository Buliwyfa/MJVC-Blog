<?php
return array (
  'Describe your files' => 'Décrivez vos fichiers',
  'Select files from dropbox' => 'Sélectionnez des fichiers depuis dropbox',
  'Submit' => 'Envoyer',
);
