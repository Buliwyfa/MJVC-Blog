<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Attention !</strong> Vous partager des fichiers privés',
  'Cancel' => 'Annuler',
  'Do not show this warning in future' => 'Ne plus afficher cet avertissement à l\'avenir',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Les fichiers que vous souhaitez partager sont privés. Pour pouvoir partager des fichiers dans votre espace, nous avons généré un lien de partage. Toute personne qui connait ce lien peut accéder au fichier.<br/>Vous êtes sûr de vouloir partager ?',
  'Yes, I\'m sure' => 'Oui, je suis sûr',
);
