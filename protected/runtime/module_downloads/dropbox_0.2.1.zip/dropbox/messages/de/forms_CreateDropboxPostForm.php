<?php
return array (
  'Invalid file' => 'Unzulässige Datei',
  'Message' => 'Nachricht',
);
