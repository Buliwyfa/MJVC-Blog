<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Vorsicht!</strong> Du teilst private Dateien',
  'Cancel' => 'Abbrechen',
  'Do not show this warning in future' => 'Die Warnung künftig nicht mehr anzeigen',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Du möchtest private Dateien teilen. Zur Anzeige der Dateien in deinem space wird ein Link auf die privaten Dateien generiert. Jedermann, der diesen Link sehen kann, wir auf diene privaten Dateien Zugriff haben<br/>Bist du sicher, dass du diese Dateien teilen möchstest?',
  'Yes, I\'m sure' => 'Ja, ich bin sicher',
);
