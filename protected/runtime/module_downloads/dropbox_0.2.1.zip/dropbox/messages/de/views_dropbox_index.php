<?php
return array (
  'Describe your files' => 'Beschreibe deine Dateien',
  'Select files from dropbox' => 'Wähle Dateien aus der Dropbox',
  'Submit' => 'Absenden',
);
