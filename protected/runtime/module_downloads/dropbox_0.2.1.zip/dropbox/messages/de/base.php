<?php
return array (
  'Add Dropbox files' => 'Dropbox-Dateien hinzufügen',
);
