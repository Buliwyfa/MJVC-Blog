<?php
return array (
  'Describe your files' => 'Beschreibe deine Dateien',
);
