<?php
return array (
  'Access denied!' => 'Zugriff verweigert!',
);
