<?php
return array (
  'Dropbox post' => 'Dropbox-Post',
);
