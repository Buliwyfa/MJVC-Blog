<?php
return array (
  'Invalid file' => 'Geçersiz dosya',
  'Message' => 'Mesaj',
);
