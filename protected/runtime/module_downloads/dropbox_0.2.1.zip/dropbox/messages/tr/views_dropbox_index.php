<?php
return array (
  'Describe your files' => 'Dosyalarınızı tanımlayın',
  'Select files from dropbox' => 'Dropbox dosya seçin',
  'Submit' => 'Gönder',
);
