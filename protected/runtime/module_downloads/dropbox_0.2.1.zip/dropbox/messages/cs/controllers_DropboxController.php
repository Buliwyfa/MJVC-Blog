<?php
return array (
  'Access denied!' => 'Přístup odepřen!',
);
