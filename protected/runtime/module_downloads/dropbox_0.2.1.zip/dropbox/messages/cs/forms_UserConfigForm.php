<?php
return array (
  'Show warning on posting' => 'Zobrazit varování při odesílání',
);
