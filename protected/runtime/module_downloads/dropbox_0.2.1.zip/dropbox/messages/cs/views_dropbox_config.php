<?php
return array (
  '<strong>Dropbox</strong> settings' => '<strong>Nastavení</strong> Dropboxu',
  'Submit' => 'Potvrdit',
);
