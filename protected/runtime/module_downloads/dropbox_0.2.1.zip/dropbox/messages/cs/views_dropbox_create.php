<?php
return array (
  'Describe your files' => 'Popište své soubory',
);
