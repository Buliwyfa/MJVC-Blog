<?php
return array (
  'Invalid file' => 'Neplatný soubor',
  'Message' => 'Zpráva',
);
