<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Upozornění!</strong> Chystáte se sdílet soukromé soubory',
  'Cancel' => 'Zrušit',
  'Do not show this warning in future' => 'Nechci toto upozornění už znovu zobrazovat',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Soubory, které se chystáte sdílet, jsou označeny jako soukromé. Odteď je však budou moci číst všichni, kdo obdrží odkaz k těmto souborům. Chcete tyto soubory opravdu sdílet?',
  'Yes, I\'m sure' => 'Ano, opravdu jsem si jist(a)',
);
