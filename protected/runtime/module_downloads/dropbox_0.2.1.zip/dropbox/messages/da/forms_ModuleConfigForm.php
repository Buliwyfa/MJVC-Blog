<?php
return array (
  'Dropbox API Key' => 'Dropbox API nøgle',
);
