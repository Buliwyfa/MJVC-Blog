<?php
return array (
  'Back to modules' => 'Tilbage til moduler',
  'Dropbox Module Configuration' => 'Dropbox Modul Konfiguration',
  'Save' => 'Gem',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Dropbox modulet skal bruge en aktiv dropbox konto. Venligst gå til denne <a href="%link%" target="_blank"><strong>side</strong></a>, vælg "Drop-ins app" og giv et app navn for at få din API nøgle.',
);
