<?php
return array (
  'Add Dropbox files' => 'Tilføjet Dropbox filer',
);
