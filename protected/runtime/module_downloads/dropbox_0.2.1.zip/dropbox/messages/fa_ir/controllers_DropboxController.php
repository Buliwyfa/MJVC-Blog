<?php
return array (
  'Access denied!' => 'دسترسي تاييد نشد',
);
