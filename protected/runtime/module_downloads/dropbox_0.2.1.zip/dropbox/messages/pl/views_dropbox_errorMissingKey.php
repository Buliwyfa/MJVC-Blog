<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Przepraszamy, moduł Dropbox nie jest jeszcze skonfigurowany! Skontaktuj się z Administratorem.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Moduł Dropbox nie jest jeszcze skonfigurowany!  Zmień ustawienia <a href="%link%"><strong>tutaj</strong></a>.',
);
