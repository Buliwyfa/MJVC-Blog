<?php
return array (
  'Describe your files' => 'Opis dla Twoich plików',
  'Select files from dropbox' => 'Wybierz pliki z Dropbox',
  'Submit' => 'Prześlij',
);
