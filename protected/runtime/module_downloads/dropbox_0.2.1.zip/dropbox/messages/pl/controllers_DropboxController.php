<?php
return array (
  'Access denied!' => 'Brak dostępu!',
);
