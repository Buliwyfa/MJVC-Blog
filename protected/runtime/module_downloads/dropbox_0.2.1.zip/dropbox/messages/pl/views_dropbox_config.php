<?php
return array (
  '<strong>Dropbox</strong> settings' => 'Ustawienia <strong>Dropbox</strong>',
  'Submit' => 'Prześlij',
);
