<?php
return array (
  'Invalid file' => 'Неверный формат файла',
  'Message' => 'Сообщение',
);
