<?php
return array (
  'Access denied!' => 'Доступ запрещен!',
);
