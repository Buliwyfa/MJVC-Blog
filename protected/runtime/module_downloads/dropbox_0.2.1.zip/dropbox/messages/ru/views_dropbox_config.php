<?php
return array (
  '<strong>Dropbox</strong> settings' => '<strong>Настройки</strong> дропбокс',
  'Submit' => 'Принять',
);
