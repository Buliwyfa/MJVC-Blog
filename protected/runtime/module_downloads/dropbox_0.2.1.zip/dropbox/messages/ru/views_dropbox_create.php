<?php
return array (
  'Describe your files' => 'Опишите ваши файлы',
);
