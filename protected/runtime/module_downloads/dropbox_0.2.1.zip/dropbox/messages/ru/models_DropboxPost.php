<?php
return array (
  'Dropbox post' => 'Дропбокс сообщение',
);
