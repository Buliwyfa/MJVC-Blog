<link href="<?php echo $this->theme->getBaseUrl() . '/css/theme.css'; ?>" rel="stylesheet">
<link href="<?php echo $this->theme->getBaseUrl() . '/font/open_sans/open-sans.css'; ?>" rel="stylesheet">