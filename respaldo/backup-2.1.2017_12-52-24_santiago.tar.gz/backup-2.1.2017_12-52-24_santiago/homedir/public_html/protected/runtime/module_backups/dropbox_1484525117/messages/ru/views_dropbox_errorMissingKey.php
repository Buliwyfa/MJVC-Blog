<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'К сожалению, модуль Дропбокс еще не настроен! Пожалуйста, свяжитесь с администратором.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Модуль Dropbox еще не настроен! Пожалуйста настройте его <a href="%link%"><strong>здесь</strong></a>.',
);
