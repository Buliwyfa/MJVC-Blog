<?php
return array (
  'Back to modules' => 'Powrót do modułów',
  'Dropbox Module Configuration' => 'Konfiguracja modułu Dropbox',
  'Save' => 'Zapisz',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Moduł Dropbox wymaga utworzenia aktywnej aplikacji dropbox-owej! Przejdź na tę <a href="%link%" target="_blank"><strong>stronę</strong></a>. Wybierz "Drop-ins app" a następnie wpisz nazwę aplikacji aby uzyskać klucz do API.',
);
