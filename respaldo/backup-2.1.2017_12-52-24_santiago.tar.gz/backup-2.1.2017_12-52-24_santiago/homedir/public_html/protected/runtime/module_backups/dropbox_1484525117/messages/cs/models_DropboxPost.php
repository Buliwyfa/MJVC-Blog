<?php
return array (
  'Dropbox post' => 'Příspěvek do Dropboxu',
);
