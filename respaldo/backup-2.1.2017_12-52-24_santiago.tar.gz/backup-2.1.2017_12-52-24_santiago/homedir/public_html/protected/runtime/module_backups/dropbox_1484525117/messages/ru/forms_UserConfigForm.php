<?php
return array (
  'Show warning on posting' => 'Показать предупреждение в публикации',
);
