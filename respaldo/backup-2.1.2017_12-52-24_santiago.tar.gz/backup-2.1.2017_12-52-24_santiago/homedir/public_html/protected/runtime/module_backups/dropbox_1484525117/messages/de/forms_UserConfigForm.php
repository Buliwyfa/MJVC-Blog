<?php
return array (
  'Show warning on posting' => 'Beim Absenden Warnung zeigen',
);
