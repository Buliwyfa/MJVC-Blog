<?php
return array (
  'Back to modules' => 'Zurück zu den Modulen',
  'Dropbox Module Configuration' => 'Dropbox-Modul Konfiguration',
  'Save' => 'Speichern',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Das Dropbox-Modul benötigt ein aktives Dropbox-Konto! Bitte gehe zu <a href="%link%" target="_blank"><strong>Seite</strong></a>, wähle "Drop-ins app" und vergebe einen Applikationsnamen, um deinen API-Schlüssel zu erhalten.',
);
