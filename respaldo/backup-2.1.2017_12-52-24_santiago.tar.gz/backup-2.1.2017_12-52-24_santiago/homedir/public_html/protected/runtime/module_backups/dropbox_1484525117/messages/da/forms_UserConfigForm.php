<?php
return array (
  'Show warning on posting' => 'Vis advarsel i opslag',
);
