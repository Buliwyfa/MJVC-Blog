<?php
return array (
  'Back to modules' => 'Zpět do přehledu modulů',
  'Dropbox Module Configuration' => 'Nastavení modulu Dropbox',
  'Save' => 'Uložit',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Modul Dropbox vyžaduje přístup k Dropboxu! Přejděte prosím <a href="%link%" target="_blank"><strong>do nastavení Dropboxu</strong></a>, vyberte "Drop-ins app", zadejte jméno aplikace a potvrďte. Tak obdržítě API klíč.',
);
