<?php
return array (
  'Back to modules' => 'Назад к модулям',
  'Dropbox Module Configuration' => 'Конфигурация модуля Дропбокс',
  'Save' => 'Сохранить',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Для модуля Дропбокс требуется активация приложения Дропбокс! Пожалуйста перейдите по этой ссылке <a href="%link%" target="_blank"><strong>site</strong></a>, выберите "Drop-ins app" введите имя приложения, чтобы получить свой ключ API.',
);
