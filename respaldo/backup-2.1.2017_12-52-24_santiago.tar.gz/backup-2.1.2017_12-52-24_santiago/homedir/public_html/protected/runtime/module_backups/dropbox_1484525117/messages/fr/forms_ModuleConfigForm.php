<?php
return array (
  'Dropbox API Key' => 'Clé API Dropbox',
);
