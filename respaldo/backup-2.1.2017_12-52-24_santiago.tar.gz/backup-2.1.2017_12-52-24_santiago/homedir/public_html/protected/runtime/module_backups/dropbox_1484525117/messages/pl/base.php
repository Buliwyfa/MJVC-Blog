<?php
return array (
  'Add Dropbox files' => 'Dodaj pliki z Dropbox',
);
