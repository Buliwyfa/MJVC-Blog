<?php
return array (
  'Show warning on posting' => 'Afficher un avertissement lors d\'une contribution',
);
