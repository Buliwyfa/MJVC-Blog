<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Désolé, le module Dropbox n\'est pas encore configuré ! Merci de contacter l\'administrateur.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Le module Dropbox n\'est pas encore configuré ! Merci de le configurer <a href="%link%"><strong>ici</strong></a>.',
);
