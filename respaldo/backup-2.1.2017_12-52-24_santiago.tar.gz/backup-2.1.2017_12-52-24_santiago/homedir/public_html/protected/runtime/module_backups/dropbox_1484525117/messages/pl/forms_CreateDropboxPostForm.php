<?php
return array (
  'Invalid file' => 'Nieprawidłowy plik',
  'Message' => 'Komunikat',
);
