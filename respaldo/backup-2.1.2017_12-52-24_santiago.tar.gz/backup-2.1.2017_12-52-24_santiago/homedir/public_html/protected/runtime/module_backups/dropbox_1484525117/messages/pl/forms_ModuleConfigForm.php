<?php
return array (
  'Dropbox API Key' => 'Klucz API Dropbox',
);
