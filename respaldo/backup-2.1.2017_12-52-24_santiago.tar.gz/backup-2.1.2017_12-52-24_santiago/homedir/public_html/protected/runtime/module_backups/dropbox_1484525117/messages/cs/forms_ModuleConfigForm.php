<?php
return array (
  'Dropbox API Key' => 'API klíč k Dropboxu',
);
