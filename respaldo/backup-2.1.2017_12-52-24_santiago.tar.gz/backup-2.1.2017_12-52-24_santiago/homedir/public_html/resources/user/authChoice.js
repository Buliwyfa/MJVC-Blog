$("#btnAuthChoiceMore").click(function () {
    $("#btnAuthChoiceMore").hide();
    $(".authChoiceMore").show();
});